﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Nexus.Erp.Domain.Enums
{
    public enum PaymentMethod
    {
        Cash = 1,              
        CreditCard = 2,        
        InstaPay = 3,          
        MobileWallet = 4,
        OnAccount = 5,         
        BankTransfer = 6
    }
}
