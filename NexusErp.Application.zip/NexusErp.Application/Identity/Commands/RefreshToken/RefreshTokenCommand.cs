﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NexusErp.Application.Identity.Commands.RefreshToken
{
    internal class RefreshTokenCommand
    {
    }
}
